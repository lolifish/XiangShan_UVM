#ifndef __xspcomm_xinstance__
#define __xspcomm_xinstance__

namespace xspcomm {

int test_xdata();

}

#endif
