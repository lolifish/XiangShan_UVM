#pragma once

#ifndef XSPCOMM_VERSION

#define XSPCOMM_VERSION "0.0.1@master-63d5380-2025-08-14"
#define ENABLE_XCOROUTINE true
#define HAVE_EXECINFO_H 1

#endif
