#pragma once
#include "picker.hpp"

namespace picker { namespace codegen {

    void render_md_addr_generator(const std::vector<VariableInfo> &varibles, picker::export_opts &opts);
    
}}; // namespace picker::codegen