// This test really only includes all the type_safe header and checks we can so a build
#include <type_safe/arithmetic_policy.hpp>
#include <type_safe/boolean.hpp>
#include <type_safe/bounded_type.hpp>
#include <type_safe/compact_optional.hpp>
#include <type_safe/config.hpp>
#include <type_safe/constrained_type.hpp>
#include <type_safe/deferred_construction.hpp>
#include <type_safe/downcast.hpp>
#include <type_safe/flag.hpp>
#include <type_safe/flag_set.hpp>
#include <type_safe/floating_point.hpp>
#include <type_safe/index.hpp>
#include <type_safe/integer.hpp>
#include <type_safe/narrow_cast.hpp>
#include <type_safe/optional.hpp>
#include <type_safe/optional_ref.hpp>
#include <type_safe/output_parameter.hpp>
#include <type_safe/reference.hpp>
#include <type_safe/strong_typedef.hpp>
#include <type_safe/tagged_union.hpp>
#include <type_safe/types.hpp>
#include <type_safe/variant.hpp>
#include <type_safe/visitor.hpp>

int main( )
{
    return 0;
}
