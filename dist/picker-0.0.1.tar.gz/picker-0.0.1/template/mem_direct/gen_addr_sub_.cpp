#include "gen_addr.hpp"

void render_varible_info_{{__sub_i__}}(BaseType &base)
{
    {{__yaml_varible_info_{{__sub_i__}}__}}

    return;
}